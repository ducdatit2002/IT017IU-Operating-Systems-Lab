#include <iostream>
using namespace std;
int main() {
cout << "Welcome To Geeks For Geeks For Geeks";
return 0;
}