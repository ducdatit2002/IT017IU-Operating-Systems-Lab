#include <stdio.h>
int main() {
printf("welcome to geeks for geeks");
return 0;
}